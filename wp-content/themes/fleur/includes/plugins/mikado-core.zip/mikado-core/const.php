<?php

define('MIKADO_CORE_VERSION', '1.0.2');
define('MIKADO_CORE_ABS_PATH', dirname(__FILE__));
define('MIKADO_CORE_REL_PATH', dirname(plugin_basename(__FILE__)));
define('MIKADO_CORE_CPT_PATH', MIKADO_CORE_ABS_PATH.'/post-types');
define('MIKADO_CORE_SHORTCODES_PATH', MIKADO_CORE_ABS_PATH . '/shortcodes' );