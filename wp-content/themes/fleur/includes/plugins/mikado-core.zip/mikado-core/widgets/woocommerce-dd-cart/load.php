<?php

if( fleur_mikado_is_plugin_installed('woocommerce') ) {
	require_once MIKADO_CORE_ABS_PATH . '/widgets/woocommerce-dd-cart/woocommerce-dropdown-cart.php';
}