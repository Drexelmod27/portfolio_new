<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/separator/separator.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/separator/custom-styles/separator.php';

