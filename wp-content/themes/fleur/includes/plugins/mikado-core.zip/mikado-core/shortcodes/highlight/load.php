<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/highlight/highlight.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/highlight/custom-styles/highlight.php';