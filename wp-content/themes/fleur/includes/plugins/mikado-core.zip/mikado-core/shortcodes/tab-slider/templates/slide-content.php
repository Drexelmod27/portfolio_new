<div class="mkd-tab-slide-content">
    <?php echo fleur_mikado_remove_auto_ptag($content, true); ?>
</div>
