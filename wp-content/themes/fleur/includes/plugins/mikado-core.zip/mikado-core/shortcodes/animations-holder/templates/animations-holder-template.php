<div <?php fleur_mikado_class_attribute($class); ?> <?php echo fleur_mikado_get_inline_attrs($data); ?>>
	<div <?php fleur_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>