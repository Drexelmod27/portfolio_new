<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blog-list/blog-list.php';
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/blog-list/custom-styles/blog-list.php';